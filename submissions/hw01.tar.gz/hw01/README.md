### Name
Kim Whitney

### CCIS Username
kawhitney

### Github Repo
[Kimception CS4550](https://github.com/kimception/cs4550)

### Domain Name
www.sorryiateallyourpancakes.com

##### Distance in CodeAcademy Tutorials
Around halfway for CSS and none in HTML. I have a lot of experience in web dev (personally and in my third co-op) so I'm pretty familiar with HTML and CSS basics.
