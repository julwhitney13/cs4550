### Name
Kim Whitney

### Github Repo
[Kimception CS4550 HW02](https://github.com/kimception/cs4550/tree/master/hw02)

### Domain Name
www.sorryiateallyourpancakes.com

### HW02 Link
www.hw02.sorryiateallyourpancakes.com
