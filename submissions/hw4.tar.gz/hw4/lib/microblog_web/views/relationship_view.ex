defmodule MicroblogWeb.RelationshipView do
  use MicroblogWeb, :view
end
