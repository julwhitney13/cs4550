defmodule MicroblogWeb.UserView do
  use MicroblogWeb, :view
end
