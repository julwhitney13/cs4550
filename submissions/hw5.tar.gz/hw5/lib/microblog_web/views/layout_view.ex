defmodule MicroblogWeb.LayoutView do
  use MicroblogWeb, :view
end
