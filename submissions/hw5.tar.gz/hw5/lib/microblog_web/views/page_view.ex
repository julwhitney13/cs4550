defmodule MicroblogWeb.PageView do
  use MicroblogWeb, :view
end
