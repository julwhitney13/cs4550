defmodule MicroblogWeb.PostView do
  use MicroblogWeb, :view
end
